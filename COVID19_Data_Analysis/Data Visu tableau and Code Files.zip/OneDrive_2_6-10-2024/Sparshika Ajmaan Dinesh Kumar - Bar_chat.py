import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

# Load data
df = pd.read_csv('covid_19_clean_complete.csv')

# Summarize data by country
country_summary = df.groupby('Country/Region')[['Confirmed', 'Deaths']].sum().reset_index()
top_10 = country_summary.nlargest(10, 'Confirmed')

# Plotting
plt.figure(figsize=(14, 7))
bar_width = 0.4
r1 = range(len(top_10))
r2 = [x + bar_width for x in r1]

plt.bar(r1, top_10['Confirmed'], color='blue', width=bar_width, edgecolor='grey', label='Confirmed Cases')
plt.bar(r2, top_10['Deaths'], color='grey', width=bar_width, edgecolor='grey', label='Deaths')

plt.xlabel('Country', fontweight='bold')
plt.xticks([r + bar_width/2 for r in range(len(top_10))], top_10['Country/Region'], rotation=45)
plt.ylabel('Count')

# Format y-axis to display millions or billions
def y_fmt(value, position):
    if value >= 1000000000:
        return f'{value / 1000000000:.1f}B'
    elif value >= 1000000:
        return f'{value / 1000000:.1f}M'
    else:
        return f'{value:.0f}'

plt.gca().yaxis.set_major_formatter(FuncFormatter(y_fmt))

plt.title('Top 10 Countries by Confirmed Cases and Deaths')
plt.legend()
plt.tight_layout()
plt.show()
